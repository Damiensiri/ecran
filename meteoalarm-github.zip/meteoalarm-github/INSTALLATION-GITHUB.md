# Installer la vigilance MeteoAlarm sur GitHub Pages

Cette version ne nécessite aucun compte Météo-France, aucune clé API et aucun secret GitHub.

## 1. Placer les fichiers

Dans la racine du dépôt GitHub Pages `damiensiri.github.io`, placer exactement cette structure :

```text
damiensiri.github.io/
├── .github/
│   └── workflows/
│       └── update-vigilance.yml
├── scripts/
│   └── update-vigilance.py
├── vigilance-data.js
├── vigilance.json
└── weather.html
```

`weather.html`, `vigilance-data.js` et `vigilance.json` doivent rester dans le même dossier. Le dossier `.github` peut être masqué sur macOS : dans le Finder, utiliser `Commande + Majuscule + .` pour l'afficher.

## 2. Envoyer les fichiers sur GitHub

1. Ouvrir le dépôt `damiensiri.github.io` sur GitHub.
2. Ajouter les fichiers ci-dessus en conservant exactement leurs dossiers.
3. Valider avec le message `Ajout de la vigilance MeteoAlarm`.

## 3. Autoriser la mise à jour automatique

1. Dans le dépôt, ouvrir **Settings**.
2. Ouvrir **Actions**, puis **General**.
3. Descendre jusqu'à **Workflow permissions**.
4. Sélectionner **Read and write permissions**.
5. Cliquer sur **Save**.

Cette autorisation permet uniquement au robot GitHub de mettre à jour `vigilance.json` et `vigilance-data.js` dans le dépôt.

## 4. Lancer le premier test

1. Ouvrir l'onglet **Actions** du dépôt.
2. Choisir **Mettre à jour la vigilance Aube**.
3. Cliquer sur **Run workflow**, puis de nouveau sur **Run workflow**.
4. Attendre que le voyant devienne vert.
5. Recharger la page GitHub Pages.

## Fonctionnement

- GitHub interroge le flux public MeteoAlarm toutes les 15 minutes.
- Le script conserve uniquement les alertes qui concernent l'Aube.
- Il choisit le niveau maximal : vert, jaune, orange ou rouge.
- Il traduit les phénomènes principaux en français.
- Il ne crée un nouveau commit que lorsque la vigilance de l'Aube change.
- La page lit un fichier local : aucun blocage CORS ou cookie tiers sur mobile.

La source reste attribuée à **MeteoAlarm / EUMETNET**, conformément à la licence CC BY 4.0.

## Dépannage

Si le workflow affiche une erreur lors de `git push`, vérifier l'étape **Workflow permissions**. Si GitHub Pages publie depuis un autre dossier que la racine, placer `weather.html`, `vigilance-data.js` et `vigilance.json` ensemble dans ce dossier et adapter `OUTPUT_DIR` dans `scripts/update-vigilance.py`.
